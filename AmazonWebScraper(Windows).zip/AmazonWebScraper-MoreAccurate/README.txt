- Vanya Kootchin - 
-   01/21/2020   -
-     <*_*>      -
- AMWSGitCommand - 


Installation:

	Requirements:
	- Python 3.8 upwards
	- GitBash w/ .bashrc file that is used

	in terminal @ AmazonWebScraper-MoreAccurate
	type:
		chmod u+x INSTALL.sh
                ./INSTALL.sh

Use:
	In Git Bash shell type:

		amazon (your search query)

	- No brackets or "" needed

	Will return the best results by formula and similarity to search 	query


DIFFERENCES BETWEEN MAC AND WINDOWS:
Respectively
	    
            bin/activate = Scripts/activate
                 python3 = python 