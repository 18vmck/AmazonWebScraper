##!/bin/bash
# _INSTALL SCRIPT_
#
# For AmazonWebScraper-MoreAccurate Program
#
#   - Creates venv
#   - Adds .bashrc variable for installation directory 
#
#   - ADDS DIRECTLY TO .BASHRC, if you want to change .file do so manually below
#

INSTALL_DIRECTORY=$(pwd)

#Installing the appropriate path in .bashrc
#_____________________________________________
cd ~
echo "" >> .bashrc # These add new line characters
echo "" >> .bashrc
echo "# Amazon Git Command Installation Path Variable" >> .bashrc
echo "# Vanya Kootchin TM" >> .bashrc
echo "# =================" >> .bashrc
echo "export AMWSDirectory='$INSTALL_DIRECTORY'" >> .bashrc
echo "# Command" >> .bashrc
echo "source '$INSTALL_DIRECTORY/python-code/resources/.command.sh'" >> .bashrc
echo "# =================" >> .bashrc
#_____________________________________________



# Creating the virtual environment
#_____________________________________________
cd "$INSTALL_DIRECTORY/python-code"
echo -e "\e[1;31mCreating virtual environment...\e[0m"
python3 -m venv AmazonWSMA-venv
source AmazonWSMA-venv/Scripts/activate
echo -e "\e[1;31mInstalling packages...\e[0m"
python3 -m pip install --upgrade pip
pip install fuzzywuzzy requests selectorlib
echo -e "\e[1;31mInstallation finished.\e[0m"
#_____________________________________________