#!/bin/bash

#Helpful for visuals
function pause(){
 read -s -n 1 -p "Press any key to continue . . ."
 echo ""
} # pause ()

function amazon()   {
    # Nice formatting
    cwd=$(pwd)
    printf '\e[8;45;150t' # differ for mac
    clear

    #activate Virtual Environment
    source "$AMWSDirectory/python-code/AmazonWSMA-venv/bin/activate" # differ for mac
    echo "AmazonWSMA-venv activate"
    cd "$AMWSDirectory/python-code"
    
    #Executing the python code
    python3 url_gen.py "$1 $2 $3 $4 $5 $6 $7 $8 $9" # differ for mac
    python3 searchresults.py # differ for mac
    echo -e "================================================================AMAZON_RESULTS================================================================"
    python3 -W ignore format.py "$1 $2 $3 $4 $5 $6 $7 $8 $9" # differ for mac
    echo -e "=============================================================================================================================================="
    
    #Clean up 
    cd "$cwd"
    deactivate AmazonWSMA-venv
    pause
    printf '\e[8;24;80t' # differ for mac
    clear
    rl

} # amazon()

